package wsk

import (
	"ai-web-agent-server/pkg/wsk/stru"
	"encoding/json"
	"fmt"
	"log"
	"testing"
)

func TestStru(t *testing.T) {
	req := stru.Request{}
	req.TranType = "request"
	req.Type = "commard"
	req.Action = "get_dom"

	jsonSTR, err := json.Marshal(req)
	if err != nil {
		log.Println("❌ Error:", err)
	}

	fmt.Println(string(jsonSTR))

}

func TestClick(t *testing.T) {
	err := SendClickCommandTo("nueng", "#fQuote > div:nth-child(4) > button")
	if err != nil {
		log.Println("❌ Error:", err)
	}
	fmt.Println("✅ Click command sent to #yearcar for user nueng")
}
